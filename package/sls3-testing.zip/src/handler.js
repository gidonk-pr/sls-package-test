
'use strict';

module.exports.hello = (event, context, callback) => {
  const response = {
    statusCode: 200,
    body: JSON.stringify({
        message: createrequest(event, context),
      }),
  };
  callback(null, response);
};


function createrequest(event, context) {
  return JSON.stringify(
    {
      functionName:       context.functionName,
      invokedFunctionArn: context.invokedFunctionArn,
      logGroupName:       context.logGroupName,
      logStreamName:      context.logStreamName,
      event:              JSON.stringify(event, null, 2)
    }
  );
}

module.exports.createrequest = createrequest;
